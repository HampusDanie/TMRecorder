//
//  AppDelegate.m
//  TimeRecord
//
//  Created by FLYang on 2017/3/15.
//  Copyright © 2017年 Fynn. All rights reserved.
//

#import "AppDelegate.h"
#import "RunTool.h"
//Shorthand.iosApp
@interface AppDelegate ()
 @property (nonatomic, assign) BOOL isRun;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    //  启动图停留时间
   //[NSThread sleepForTimeInterval:1];
    
    return YES;
}



- (void)applicationDidEnterBackground:(UIApplication *)application {


    _isRun = YES;
    [[RunTool sharedBg] startRunInbackGround];
    

}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    

    

    if (_isRun){
        [[RunTool sharedBg] stopAudioPlay];
        _isRun = NO;
    }

}


@end
