//
//  FYYViewController.m
//  TimeRecord
//
//  Created by FLYang on 2017/3/15.
//  Copyright © 2017年 Fynn. All rights reserved.
//

#import "FYYViewController.h"
#import "FYYWriteViewController.h"
#import "SRViewController.h"
#import "XMWeatherView.h"
#define KScreenWidth  [UIScreen mainScreen].bounds.size.width
#define KScreenHeight  [UIScreen mainScreen].bounds.size.height
@interface FYYViewController ()
@property(nonatomic,strong) UIView *backgroundView;

@property(nonatomic,strong) XMWeatherView *weatherView;
@end

@implementation FYYViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *imageview = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)] ;
    imageview.image = [UIImage imageNamed:@"zhuozi"] ;
    [self.view addSubview:imageview] ;
    
//    UIButton *button0  = [[UIButton alloc]initWithFrame:CGRectMake(self.view.frame.size.width - 80, self.view.frame.size.height- 170, 60, 60)] ;
//
//    [self.view addSubview:button0] ;
    
 
    

    self.backgroundView=[[UIView alloc] initWithFrame:self.view.frame];
    
    [self.view addSubview:_backgroundView];
    self.weatherView=nil;
    self.weatherView=[[XMWeatherView alloc] initWithFrame:self.view.frame andEffect:@"sakura"];
    [self.backgroundView addSubview:self.weatherView];
    
    UIButton *button1  = [[UIButton alloc]initWithFrame:CGRectMake(0, KScreenHeight- 100, KScreenWidth/2, 60)] ;
    [button1 addTarget:self action:@selector(xiezi) forControlEvents:UIControlEventTouchUpInside] ;
    [self.view addSubview:button1] ;
    [button1 setImage:[UIImage imageNamed:@"按钮2"] forState:UIControlStateNormal] ;
    
    UIButton *button2  = [[UIButton alloc]initWithFrame:CGRectMake(KScreenWidth/2, KScreenHeight-100, KScreenWidth/2, 60)] ;
    [button2 addTarget:self action:@selector(luyin) forControlEvents:UIControlEventTouchUpInside] ;
    
    [button2 setImage:[UIImage imageNamed:@"按钮1"] forState:UIControlStateNormal] ;
    
    [self.view addSubview:button2] ;
    
}
- (void)luyin{
   
    SRViewController *srVC = [[SRViewController alloc] init];
    UINavigationController *navi = [[UINavigationController alloc] initWithRootViewController:srVC];
    [self presentViewController:navi animated:YES completion:nil];
    
}
- (void)xiezi{

    FYYWriteViewController *ss = [[FYYWriteViewController alloc]init] ;
    [self presentViewController:ss animated:YES completion:nil] ;
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    
  

}

@end
