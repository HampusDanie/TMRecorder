//
//  XMWeatherView.h
//  AlphaGoFinancial
//
//  Copyright © 2016年 wxm. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XMWeatherView : UIView
@property(nonatomic,strong) CAEmitterLayer *sunshineEmitterLayer;

@property(nonatomic,strong) CAEmitterLayer *rainDropEmitterLayer;

@property(nonatomic,strong) UIImageView *backgroundView;
-(instancetype)initWithFrame:(CGRect)frame andEffect:(NSString *)effect;

@end
