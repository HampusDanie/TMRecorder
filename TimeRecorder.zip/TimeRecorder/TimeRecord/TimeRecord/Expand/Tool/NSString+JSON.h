//
//  NSString+JSON.h
//  Read
//
//  Created by FLYang on 2017/1/10.
//  Copyright © 2017年 Fynn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (JSON)

+ (NSString *)jsonStringWithObject:(id)object;

@end
