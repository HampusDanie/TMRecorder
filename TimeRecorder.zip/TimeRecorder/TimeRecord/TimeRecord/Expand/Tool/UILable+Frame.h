//
//  UILable+Frame.h
//  Fiu
//
//  Created by FLYang on 16/4/8.
//  Copyright © 2016年 taihuoniao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (Frame)

- (CGSize)boundingRectWithSize:(CGSize)size;

@end
