//
//  SlideGestureRecognizer.h
//  SlideMusicPlayer
//
//  Created by wbq on 17/2/15.
//  Copyright © 2017年 汪炳权. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SlideGestureRecognizer : UIGestureRecognizer

//旋转的角度
@property(nonatomic)CGFloat rotation;

@end
