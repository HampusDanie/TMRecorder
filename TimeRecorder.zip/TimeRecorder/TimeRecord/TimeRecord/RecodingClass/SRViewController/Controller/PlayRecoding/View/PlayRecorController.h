//
//  PlayRecorController.h
//  TimeRecord
//
//  Created by mo on 2018/9/18.
//  Copyright © 2018年 Fynn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayRecorController : UIViewController

@property (nonatomic,copy) NSString *recorderPath ;
@property (nonatomic,copy) NSString *name ;
@end



