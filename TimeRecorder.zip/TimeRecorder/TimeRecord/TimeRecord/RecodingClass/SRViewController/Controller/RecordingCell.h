//
//  RecordingCell.h
//  TimeRecord
//
//  Created by mo on 2018/9/13.
//  Copyright © 2018年 Fynn. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RecordingModel.h"
@interface RecordingCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameRec;


@property (weak, nonatomic) IBOutlet UILabel *time;
+ (instancetype) cellWithTablview:(UITableView *)tab  Withmodel :(RecordingModel*)model ;
@end
