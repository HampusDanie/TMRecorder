//
//  RecordingCell.m
//  TimeRecord
//
//  Created by mo on 2018/9/13.
//  Copyright © 2018年 Fynn. All rights reserved.
//

#import "RecordingCell.h"

@implementation RecordingCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

+(instancetype) cellWithTablview:(UITableView *)tab  Withmodel :(RecordingModel*)model
{
    
    RecordingCell *cell = [tab dequeueReusableCellWithIdentifier:@"RecordingCell"];
    
    if (!cell) {
        cell =[[[NSBundle mainBundle] loadNibNamed:@"RecordingCell" owner:self options:nil] lastObject];
    }
//    cell.nameRec.text = model.name;
//    //  cell.titleLabel.text = sound.name;
//    cell.time.text = model.time;
    
//    cell.nameRec.text = @"hah";
//    //  cell.titleLabel.text = sound.name;
//    cell.time.text = @"lalla";
    return cell;
    
}

@end
