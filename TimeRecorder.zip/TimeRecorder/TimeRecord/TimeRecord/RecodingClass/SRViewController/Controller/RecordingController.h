

#import <UIKit/UIKit.h>

@interface RecordingController : UIViewController

@end
