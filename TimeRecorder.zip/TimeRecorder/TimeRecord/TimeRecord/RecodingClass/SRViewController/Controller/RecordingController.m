
//

#import "RecordingController.h"
#import "RecordingCell.h"
#import "PlayRecorController.h"
#import "LLNoDataView.h"


#define RGB(r, g, b, a) [UIColor colorWithRed:(r) / 255.0 green:(g) / 255.0 blue:(b) / 255.0 alpha:(a)]
@interface RecordingController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong) UITableView * tablview ;
@property (nonatomic,strong) NSMutableArray *dataAray ;
@end

@implementation RecordingController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setNavation] ;

    
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    self.tablview = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    self.tablview.delegate = self ;
    self.tablview.dataSource = self ;
    [self.view addSubview:self.tablview] ;
    NSString *filePath=[path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",@"T1Sound.plist"]];
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {   //取出上次存的数据
        
        
     self.dataAray = [[NSMutableArray alloc]initWithContentsOfFile:filePath];
     [self.tablview reloadData];
   
    }
    if ( self.dataAray.count==0) {
        LLNoDataView *dataView = [[LLNoDataView alloc] initNoDataWithFrame:self.tablview.bounds description:@"No data" canTouch:YES];
        self.tablview.showsVerticalScrollIndicator = NO;
        self.tablview.showsHorizontalScrollIndicator =NO;
//        dataView.delegate = self;
        self.tablview.tableHeaderView = dataView;
        
    }
  
    
   
    
    
}

- (void)setNav{
    
    UIButton *button  = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];
    button.backgroundColor = [UIColor orangeColor] ;
    
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:button] ;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    RecordingCell *cell = [RecordingCell cellWithTablview:tableView Withmodel:nil] ;
    NSDictionary *dict = self.dataAray[indexPath.row] ;
    for (NSString *key in dict) {
         cell.nameRec.text = key;
        cell.time.text = [dict objectForKey:key];
    }
    
    //    //  cell.titleLabel.text = sound.name;
    //
    return cell ;
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
   return self.dataAray.count ;
      
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 78 ;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   NSDictionary *dict = self.dataAray[indexPath.row] ;
//
    for (NSString *key in dict) {
       NSString *strName = key;
        NSString *time= [dict objectForKey:key];


        NSString *path = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
        NSString *filePath = [path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.caf", time]];

        PlayRecorController *pvc = [[PlayRecorController alloc]init] ;
        pvc.recorderPath = filePath ;
        pvc.name = strName ;
        
        //[self.navigationController pushViewController:pvc animated:YES] ;
        [self presentViewController:pvc animated:YES completion:nil] ;
    }

    
}

- (void)setNavation
{
    
    UIButton *right = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 30, 30)];

    [right setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
    [right setImage:[UIImage imageNamed:@"back"] forState:UIControlStateHighlighted];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:right];
    

    [right addTarget:self action:@selector(rightButonClick) forControlEvents:UIControlEventTouchUpInside];
    
    self.navigationController.navigationBar.barTintColor = RGB(71, 188, 117, 1);
    
    //设置导航条文字颜色 白色
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor]};
    
    //设置按钮文字颜色 白色
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor] ;
    self.navigationItem.title = @"MY RECORDING";
    
    
    //13716521644   135788
}
- (void)rightButonClick{
    [self.navigationController popViewControllerAnimated:YES] ;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return UITableViewCellEditingStyleDelete;
}
-(NSString*)tableView:(UITableView*)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath*)indexpath{
    return @"Delete";
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSString *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0];
    
    NSString *filePath=[path stringByAppendingPathComponent:[NSString stringWithFormat:@"%@",@"T1Sound.plist"]];
    if([[NSFileManager defaultManager] fileExistsAtPath:filePath])
    {   

        [self.dataAray removeObjectAtIndex:indexPath.row];
        [self.dataAray writeToFile:filePath atomically:YES];
    
    }

    [self.tablview reloadData];
    
}


@end
